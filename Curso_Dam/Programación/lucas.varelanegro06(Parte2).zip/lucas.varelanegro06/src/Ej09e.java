import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.Locale;
import java.util.Scanner;


public class Ej09e {
    // e) Introducir una fecha y mostrar el día de la semana que le corresponde.
    public static void main(String[] args) throws Exception {
        Scanner t = new Scanner(System.in);
        DateTimeFormatter f = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        System.out.println("Introduce una fecha: [dd/MM/yyyy]: ");
        LocalDate fecha = LocalDate.parse(t.nextLine(),f);
        Locale españa = new Locale("es", "ES");
        System.out.println("Es "+fecha.getDayOfWeek().getDisplayName(TextStyle.FULL, españa));
}
}

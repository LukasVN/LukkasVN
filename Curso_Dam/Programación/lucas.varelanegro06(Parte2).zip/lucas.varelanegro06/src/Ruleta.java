public class Ruleta {
    public int numganador;
    public boolean par = false;
    public boolean impar = false;
    public int dinero = 10000;


public void Elegirpar() {
    par = true;
}
public void Elegirimpar() {
    impar = true;
}
public void Apostar() {
    dinero--;
    numganador = (int) ((Math.random()*(36 -0) + 0));
    if (numganador % 2 == 0 && par == true && numganador != 0) {
        dinero+=2;
    }
    else if (numganador % 2 == 0 && impar == true && numganador != 0) {
        dinero+=2;
    }
}
public int DineroActual() {
    return dinero;
}
}

import java.util.Scanner;

public class Ej13 {
    /*
     * Realiza un juego de la ruleta rusa para dos jugadores. La pistola tiene 6
     * huecos en la recámara pero solo una bala. 
     * Al empezar la partida se genera una posición al azar de la recámara para la bala 
     * de forma que puede salir en el primer disparo, en el segundo, etc. hasta el sexto. 
     * Los jugadores irán disparando sucesivamente hasta que uno de los dos se muera.
     * Crea una clase Pistola con los atributos y métodos que la definen.
     */
    public static void main(String[] args) throws Exception {
        Scanner t = new Scanner(System.in);
        boolean muerto = false;
        Pistola revolver = new Pistola();
        while (!muerto) {
            System.out.println("\n\n\n");
            System.out.println("Introduzca el valor indicado: ");
            System.out.println("1. Disparo Jugador 1");
            System.out.println("2. Disparo Jugador 2");
            int opcion = t.nextInt();
            switch (opcion) {
                case 1:
                    if (revolver.Disparo(muerto)) {
                        muerto = true;
                        System.out.println("El jugador 1 ha muerto");
                    }
                    break;
                case 2:
                    if (revolver.Disparo(muerto)) {
                        muerto = true;
                        System.out.println("El jugador 2 ha muerto");
                    }
                    break;
            }
        }
    }

}

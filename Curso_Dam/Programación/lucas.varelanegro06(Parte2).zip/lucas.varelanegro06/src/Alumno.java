import java.util.Scanner;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Alumno {
    public String nombrec;
    public String dni;
    public static DateTimeFormatter f = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    public LocalDate fnacimiento;
    final public String nescuela = "IES Fernando Wirtz";
    private boolean mayoredad = false;
    private boolean mayor = false;


    public Alumno() {
    }

    public Alumno(Alumno al) {
        fnacimiento = al.fnacimiento;
        nombrec = al.nombrec;
        dni = al.dni;
    }

    public void setnombrec() {
        Scanner t = new Scanner(System.in);
        nombrec = t.nextLine();
    }

    public void setDni() {
        Scanner t = new Scanner(System.in);
        dni = t.nextLine();
    }

    public void setFnacimiento() {
        Scanner t = new Scanner(System.in);
        fnacimiento = LocalDate.parse(t.nextLine(), f);
    }

    public boolean MayorEdad() {
        LocalDate mayor18 = fnacimiento.plusYears(18);
        if (mayor18.isBefore(LocalDate.now())) {
            mayoredad = true;
        }
        return mayoredad;
    }

    public boolean Mayor(Alumno al) {
        if (al.fnacimiento.isAfter(fnacimiento)) {
            mayor = true;
        }
        return mayor;
    }

    public boolean Repetido(Alumno al) {
        return al.dni == this.dni && al.nombrec == this.nombrec && al.fnacimiento == this.fnacimiento;
    }
}

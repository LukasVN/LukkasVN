import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Ej09d {
    //d) ¿Cuántos años bisiestos ha habido desde el año 1 dC?
    public static void main(String[] args) throws Exception {
        Scanner t = new Scanner(System.in);
        int nbisiestos = 0;
        LocalDate fechas = LocalDate.of(1, 1, 1);
        for (int i = 1; i<2022;i++) {
            if (fechas.isLeapYear() == true) {
                nbisiestos++;
            }
            fechas = fechas.plusYears(1);
        }
        System.out.println("Hay "+nbisiestos+" años bisiestos desde el año 1dC");

}
}

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Ej09g {
 // g) Introducir un año y decir cuántos domingos tiene.
    public static void main(String[] args) throws Exception {
        Scanner t = new Scanner(System.in);
        int domingos = 0; int ndias = 365;
        DateTimeFormatter f = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        System.out.println("Introduce un año [yyyy]");
        long año = t.nextLong();
        LocalDate añodomingo = LocalDate.parse("01/01/"+año,f);
        if (añodomingo.isLeapYear()) { //Comprobación año bisiesto
            ndias++;
        }
        for (int i = 1; i<ndias;i++) {
            if (añodomingo.getDayOfWeek().getValue() == 7) {
                domingos++;
            }
            añodomingo = añodomingo.plusDays(1);
        }
        System.out.println("El año "+año+" tiene "+domingos+ " Domingos");
        

}
}

import java.util.Random;
import java.util.Scanner;

public class Examen {
    private double nota;
    private String opcion = "abcd";
    private String respuestas = "";

    public String Respuestas() {
        for (int i=1; i<=20; i++) {
            Random random = new Random();
            respuestas += Character.toString(opcion.charAt(random.nextInt(opcion.length())));
        }
        return respuestas;
    }
    public double ExamenAlumno() {
        Scanner t = new Scanner(System.in);
        String respuestaAl;
        int posicion = 0;
        for (int i=1; i<=20; i++) {
            String comprobacion =Character.toString(respuestas.charAt(posicion));
            System.out.println("Respuesta pregunta "+i+" (a,b,c o z en caso de respuesta en blanco)");
            respuestaAl = t.nextLine(); 
            if (respuestaAl.equals(comprobacion)) {
                nota+= 0.5;
            }
            else if (respuestaAl.equals("z")) {
            }
            else if (!respuestaAl.equals(comprobacion) && !respuestaAl.equals("z")) {
                nota-=0.2;
            }
            if (nota < 0) {
                nota = 0;
            }
            posicion+=1;
        }
        return nota;
    }
}

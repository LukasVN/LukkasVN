public class Pistola {
    public int bala = (int)((Math.random()*(6 - 1)) + 1);
    public boolean muerte = false;
    public int recamara = (int)((Math.random()*(6 - 1)) + 1);

public boolean Disparo(boolean muerte) {
    if (bala == recamara) {
        muerte = true;
    }
    else if (recamara>6) {
        recamara = 1;
    }
    recamara++;
    return muerte;
}

}


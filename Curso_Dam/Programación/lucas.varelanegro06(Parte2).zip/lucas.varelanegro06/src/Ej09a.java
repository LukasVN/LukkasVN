import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Ej09a {
    /*
     * Ejercicios de fechas. Usando las clases de Java para el manejo de fechas,
     * realiza programas
     * con la siguiente funcionalidad:
     * a) Introducir tu fecha de nacimiento y muestre cuantos días han pasado hasta
     * ahora mismo.
     */
    public static void main(String[] args) throws Exception {
    Scanner t = new Scanner(System.in);
    DateTimeFormatter f = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    System.out.println(" a) Introduce tu fecha de nacimiento [DD/MM/AAAA]: ");
    LocalDate fn = LocalDate.parse(t.nextLine(),f);
    LocalDate hoy = LocalDate.now();
    long dias = fn.until(hoy, ChronoUnit.DAYS);
    System.out.println("Han pasado "+dias+" días desde tu nacimiento");
    }
}

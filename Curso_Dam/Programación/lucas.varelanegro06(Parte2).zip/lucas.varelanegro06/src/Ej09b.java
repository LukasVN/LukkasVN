import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Ej09b {
    /* b) Introducir una fecha y un número de días y calcule la fecha que se obtiene
     * al incrementar dichos días a la fecha. */
    public static void main(String[] args) throws Exception {
        Scanner t = new Scanner(System.in);
        DateTimeFormatter f = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        System.out.println("Introduzca una fecha [dd/MM/yyyy]: ");
        LocalDate fecha = LocalDate.parse(t.nextLine(),f);
        System.out.println("Introduzca un número de dias: ");
        long dias = t.nextLong();
        fecha = fecha.plusDays(dias);
        System.out.println("La fecha tras esos dias sería: "+f.format(fecha));
    }
}

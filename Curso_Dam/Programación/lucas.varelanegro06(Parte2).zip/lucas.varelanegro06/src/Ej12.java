import java.time.LocalDate;
import java.util.Scanner;

public class Ej12 {
   /* Diseña una clase llamada Alumno para gestionar los alumnos de una escuela. Contiene los
atributos: nombre completo, DNI, fecha de nacimiento y nombre de la escuela (común para todos
los alumnos). Además del constructor, los métodos set y get para cada atributo, tendrá los
siguientes métodos:
- Método que nos dice si es mayor de edad o no.
- Método al que se le pase como parámetro otro alumno y nos devuelva true si el alumno
pasado es menor que él mismo. False en caso contrario.
- Método al que se le pase como parámetro otro alumno y nos devuelva true si el alumno
pasado es exactamente igual en todos los campos (un duplicado). False en caso contrario.
Realiza a continuación un programa sencillo que use la clase definida. */ 

public static void main(String[] args) throws Exception {
   Scanner t = new Scanner(System.in);
   int opcion; boolean salir = false; 
   Alumno al1 = new Alumno();
   Alumno al2 = new Alumno();
   Alumno alactual = al1;
   do {
      opcion = pintarMenu();
      switch (opcion) {
          case 1:
          alactual.setDni();
          break;
         case 2:
          alactual.setnombrec();
          break;
          case 3:
          alactual.setFnacimiento();
          break;
         case 4: 
         System.out.println(alactual.dni);
         break;
         case 5:
         System.out.println(alactual.nombrec);
         break;
         case 6:
         System.out.println(alactual.nescuela);
         break;
         case 7: 
         System.out.println(alactual.fnacimiento);
         break;
         case 8:
         if (alactual.MayorEdad()) {
             System.out.println("Es mayor de edad");
         }
         else {
             System.out.println("Es menor de edad");
         }
         break;
         case 9:
         if (alactual.Repetido(al1) && alactual.Repetido(al2)) {
            System.out.println("El alumno está Repetido");
         }
         else {
             System.out.println("El alumno NO está Repetido");
         }
         break;
         case 10:
         if (alactual.Mayor(al2)|| alactual.Mayor(al1)) {
             System.out.println("Es MAYOR que el otro alumno");
         }
         else  {
             System.out.println("Es MENOR que el otro alumno");
         }
         break;
         case 11:
         if (alactual.equals(al1)) {
            alactual = al2;
        }
        else {
            alactual = al1;
        }
         break;
          case 0:
              salir = true;
              break;

      }
  } while (!salir);
}
  private static int pintarMenu() {
      Scanner t = new Scanner(System.in);

      System.out.println("\n\n\n");
      System.out.println("Elija una opción:");
      System.out.println("1 Introducir DNI");
      System.out.println("2 Introducir Nombre Completo");
      System.out.println("3 Introducir Fecha de Nacimiento");
      System.out.println("4 DNI Alumno");
      System.out.println("5 Nombre Alumno");
      System.out.println("6 Nombre Escuela");
      System.out.println("7 Fecha de nacimiento del alumno");
      System.out.println("8 Es mayor de edad?");
      System.out.println("9 Alumno repetido?");
      System.out.println("10 Mayor que el otro alumno?");
      System.out.println("11 Cambiar de alumno");
      System.out.println("0 Salir del programa");
      try { // si introduce un valor no entero haría return 999
          return Integer.parseInt(t.nextLine());
      } catch (Exception e) {
          return 999;
      }

  }

}

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Ej09f {
    /* f) Introducir un tipo de producto (1- perecedero, 2-electrónica, 3-ropa) y la
     * fecha de compra, y que informe si se puede devolver a día de hoy
     * o no (los plazos de devolución, son respectivamente 5 horas, 6 meses, 15
     * días) */

    public static void main(String[] args) throws Exception {
        Scanner t = new Scanner(System.in);
        boolean devolucion = true;
        LocalDateTime fechamax;
        DateTimeFormatter f = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
         int numMenu = Menu();
         System.out.println("Introduzca fecha y hora de adquisición [Día/Mes/Año Horas:minutos]: ");
         LocalDateTime fecha = LocalDateTime.parse(t.nextLine(),f);
        switch(numMenu) {
            case 1: 
            fechamax = fecha.plusHours(5);
            if (fechamax.isBefore(LocalDateTime.now())) {
                devolucion = false;
            }
            break;
            case 2: 
            fechamax = fecha.plusMonths(6);
            if (fechamax.isBefore(LocalDateTime.now())) {
                devolucion = false;
            }
            break;
            case 3:
            fechamax = fecha.plusDays(15);
            if (fechamax.isBefore(LocalDateTime.now())) {
                devolucion = false;
            }
            break;

        }
        if (devolucion) {
            System.out.println("El producto se puede devolver");
        }
        else {
            System.out.println("El producto ha excedido el periodo de devolución");
        }


    }
    private static int Menu() {
        Scanner t = new Scanner(System.in);
        System.out.println("\n\n\n");
        System.out.println("Introduce tipo de producto :");
        System.out.println("1. Perecedero");
        System.out.println("2. Electrónica");
        System.out.println("3. Ropa");
        return t.nextInt();

    }

}

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Ej09c {
    //c) Introducir dos horas de reloj y nos dé la diferencia entre ambas en segundos.
    public static void main(String[] args) throws Exception {
        Scanner t = new Scanner(System.in);
        DateTimeFormatter f = DateTimeFormatter.ofPattern("HH:mm");
        System.out.println("Introduce una hora [HH:mm]: ");
        LocalTime hora1 = LocalTime.parse(t.nextLine(),f);
        System.out.println("Introduce otra hora [HH:mm]: ");
        LocalTime hora2 = LocalTime.parse(t.nextLine(),f);
        long segundos = ChronoUnit.SECONDS.between(hora1, hora2);
        System.out.println("Han pasado "+segundos+" segundos entre una hora y la otra.");
    }
}

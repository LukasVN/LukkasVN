import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.Locale;
import java.util.Scanner;

public class Ej09h {
    /* h) Indica el día de la semana (en texto, en gallego) del 31 de diciembre de
    * los últimos 5 años. */
    public static void main(String[] args) throws Exception {
        Scanner t = new Scanner(System.in);
        int año = 2021;
        DateTimeFormatter f = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate diasemana = LocalDate.parse("31/12/2021",f);
        Locale galego = new Locale("gl", "GL");
        for (int i= 0; i<5;i++) {
        System.out.println("No "+año+" o 31 de Decembro foi "+diasemana.getDayOfWeek().getDisplayName(TextStyle.FULL, galego));
        diasemana = diasemana.minusYears(1);
        año--;
    }
}
}

package lucas.varelanegro03_15_primeros;

public class Ej01 {

    public static void main(String[] args) {
    // Mostrar por pantalla la frase "esto es un blucle" 10 veces    
        for (int i=1;i<=10; i++)
            System.out.println("Esto es un bucle");
            
                
    }
    
}

package lucas.varelanegro03_15_primeros;

import java.util.Scanner;

public class Ej02 {

    public static void main(String[] args) {
    /* Mostrar por pantalla nos n primeros números naturales, siendo n el valor
        tecleado previamente */     
        Scanner t = new Scanner(System.in);
        int n;
        
        System.out.println("Introduzca el valor de n");
        n = t.nextInt();
        System.out.println("Los "+n+" primeros números naturales son:");
        for (int i=1;i<=n; i++)
            System.out.println(i);
        
                
    }
    
}
